from setuptools import setup

setup(

    name = 'video35_calculos',
    version = '1.0',
    description= 'paquete de calculos sencillos',
    author = 'maxi',
    author_email ='maxiabdala232@gmail',
    url = 'matecaracha.onuniverse.com',
    packages = ['curso_pildora','curso_pildora.video35_calculos']

)