def sumar(op1,op2):
    print('el resultado de la suma es: ', op1+op2)

def restar(op1,op2):
    print('el resultado es la resta de: ', op1-op2)

def multiplicar(op1,op2):
    print('el resultado de la multiplicacion es: ', op1*op2)

def potencia(base, exponente):
    print('el resultado de la potencia es:' , base**exponente)

def redondear(numero):
    print('el numero redondeado es: ', round(numero))   

def dividir(dividendo, divisor):
    print('el resultado de la division es: ', dividendo/divisor)     