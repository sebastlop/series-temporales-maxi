from video35_calculos.calculos_generales import*

potencia(2,3)
dividir(4,2)