def suma(num1, num2):

    resultado = num1 + num2
    
    return resultado

hola = suma(2,3)

print(hola)

hola3 = suma(hola,hola)

print(hola3)