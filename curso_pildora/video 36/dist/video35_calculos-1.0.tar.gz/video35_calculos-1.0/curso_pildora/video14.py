for i in [1,2,3]:
    print('hola')

for i in ['primaver','vernano','otoño','invierno']:
    print(i)

# i es igual al elemebento i del elemento a recorrer
        
for i in ['hola', 1,2,3,4,5,6,'max']:
    print(i)

for estaciones_año in [1,2,3,4,5]:
    print(estaciones_año)

   